document.querySelector('.js-button').addEventListener('click', function() {
  console.log('test')
  document.querySelector('.js-grid').classList.toggle('grid--full')
})